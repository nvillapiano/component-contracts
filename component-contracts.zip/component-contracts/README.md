# component-contracts

A design system monorepo built around **component contracts** as the source of truth. Contracts are platform-agnostic JSON documents describing a component's tokens, props, variants, behavior, and usage rules. Implementations (React, SwiftUI, Compose) are derived from and validated against them.

An MCP server exposes contracts to AI agents in Cursor or Claude Desktop, enabling automated parity checks and code generation across platforms.

---

## Structure

```
packages/
  schema/        # JSON Schema + TypeScript types for ComponentContract
  contracts/     # Component contract files (.contract.json)
  tokens/        # Design tokens in W3C DTCG format (Style Dictionary)
  mcp-server/    # MCP server — exposes contracts to AI agents
apps/
  validator/     # CI script — validates contracts against schema
  web/           # React component library (Vite + Storybook)
  ios/           # SwiftUI (future)
  android/       # Jetpack Compose (future)
docs/
  architecture.md
  decisions.md
```

---

## Setup

```bash
brew install pnpm   # if needed
pnpm install
```

## Commands

| Command | Description |
|---------|-------------|
| `pnpm validate` | Validate all contracts against schema |
| `pnpm tokens:build` | Build token CSS + JSON from source |
| `pnpm dev:web` | Start Storybook dev server |
| `pnpm dev:mcp` | Start MCP server (dev mode) |
| `pnpm test` | Run Storybook component tests |
| `pnpm build` | Build all packages |

---

## Cursor / MCP integration

The `.cursor/mcp.json` is pre-configured. Open Cursor Settings → Features → MCP to verify the `component-contracts` server shows a green dot.

Available tools:

| Tool | Description |
|------|-------------|
| `get_contract` | Fetch a full contract by ID |
| `list_contracts` | List/filter all contracts |
| `update_contract` | Patch a contract and write to disk |
| `diff_contract` | Show changelog between versions |
| `find_by_token` | Blast-radius analysis for token changes |
| `get_platform_context` | Contract filtered for web / ios / android |

---

## Adding a component

1. Author `packages/contracts/src/{id}.contract.json`
2. Add the import to `packages/contracts/src/index.ts`
3. Run `pnpm validate` to confirm schema compliance
4. Implement in `apps/web/src/components/{id}/`
5. Write Storybook stories mirroring contract variants
6. Run `pnpm test` to verify

---

## Docs

- [Architecture](./docs/architecture.md)
- [Decisions](./docs/decisions.md)
